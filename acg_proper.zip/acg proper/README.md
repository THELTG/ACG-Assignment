# CA2 Applied Cryptography AY21/22S2
> ## DISM/FT/1B/06 ACG

> ###  Automated Severance System on Wireless@SG

---

<br>

## Here are some tags you can use to run the program

<br>

### To renew DSA key pair and certificate on client.py with a new password :

```ps
python ./client.py -r
```

### To invalidate image signature on client.py and send to server :

```ps
python ./client.py -d
```

### To renew RSA key pair and certificate on server.py with a new password :

```ps
python ./server.py -r
```

### **NOTE: TO RUN SCRIPT NORMALLY, DO NOT ADD ANY TAGS**


















